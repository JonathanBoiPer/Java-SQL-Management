package uf6;

import uf6.vista.Vista;

public class Rodamons {

    public static void main(String[] args) {
	new Vista();
    }
}
